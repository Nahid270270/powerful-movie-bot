# Bot main code will go here
